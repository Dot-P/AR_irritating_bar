実行コマンド
```
python ar.py
```
qボタンで終了．0.5秒毎に./captures下にpngファイルを保存．


描画する画像(仮): iraira.jpg